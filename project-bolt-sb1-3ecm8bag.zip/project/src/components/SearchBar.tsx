import { useState, useRef, useEffect, useCallback } from 'react';
import { Search, MapPin, X, Loader2, Globe } from 'lucide-react';
import type { CitySearchResult } from '@/types';

interface SearchBarProps {
  onSearch: (city: CitySearchResult) => void;
  autoFocus?: boolean;
}

export function SearchBar({ onSearch, autoFocus }: SearchBarProps) {
  const [query, setQuery] = useState('');
  const [showResults, setShowResults] = useState(false);
  const [results, setResults] = useState<CitySearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (autoFocus) {
      inputRef.current?.focus();
    }
  }, [autoFocus]);

  const searchCities = useCallback(async (q: string) => {
    if (q.trim().length < 2) {
      setResults([]);
      setLoading(false);
      return;
    }

    try {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
      const res = await fetch(
        `${supabaseUrl}/functions/v1/city-search?q=${encodeURIComponent(q.trim())}`,
        {
          headers: {
            Authorization: `Bearer ${anonKey}`,
            'X-Client-Info': 'citypulse',
          },
        }
      );

      if (!res.ok) {
        setResults([]);
        return;
      }

      const data = await res.json();
      setResults(data.results ?? []);
    } catch {
      setResults([]);
    } finally {
      setLoading(false);
    }
  }, []);

  function handleChange(value: string) {
    setQuery(value);
    setShowResults(true);
    setLoading(true);

    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      searchCities(value);
    }, 300);
  }

  function handleSelect(city: CitySearchResult) {
    setQuery(city.label);
    setShowResults(false);
    onSearch(city);
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (results.length > 0) {
      handleSelect(results[0]);
    } else if (query.trim()) {
      setShowResults(false);
    }
  }

  return (
    <div className="relative w-full max-w-2xl mx-auto">
      <form onSubmit={handleSubmit}>
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => handleChange(e.target.value)}
            onFocus={() => setShowResults(true)}
            onBlur={() => setTimeout(() => setShowResults(false), 200)}
            placeholder="Search any city or village worldwide..."
            className="w-full pl-12 pr-10 py-3 text-sm bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-800 dark:text-slate-200 placeholder:text-slate-400 transition-all"
          />
          <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1">
            {loading && <Loader2 className="w-4 h-4 text-slate-400 animate-spin" />}
            {query && !loading && (
              <button
                type="button"
                onClick={() => {
                  setQuery('');
                  setResults([]);
                  inputRef.current?.focus();
                }}
                className="p-1 rounded-md hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                aria-label="Clear search"
              >
                <X className="w-4 h-4 text-slate-400" />
              </button>
            )}
          </div>
        </div>
      </form>

      {showResults && (query.length >= 2 || results.length > 0) && (
        <div className="absolute top-full mt-2 w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-lg overflow-hidden z-40 animate-fade-in max-h-72 overflow-y-auto">
          {loading ? (
            <div className="flex items-center justify-center gap-2 px-4 py-6 text-sm text-slate-400">
              <Loader2 className="w-4 h-4 animate-spin" />
              Searching worldwide...
            </div>
          ) : results.length === 0 ? (
            <div className="flex flex-col items-center justify-center gap-2 px-4 py-6 text-center">
              <Globe className="w-5 h-5 text-slate-300 dark:text-slate-700" />
              <p className="text-sm text-slate-400">
                {query.trim().length >= 2
                  ? 'No locations found. Try a different spelling.'
                  : 'Type at least 2 characters to search'}
              </p>
            </div>
          ) : (
            results.map((city) => (
              <button
                key={`${city.id}-${city.name}`}
                onClick={() => handleSelect(city)}
                className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors text-left"
              >
                <MapPin className="w-4 h-4 text-slate-400 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <span className="text-sm font-medium text-slate-700 dark:text-slate-300 block truncate">
                    {city.name}
                  </span>
                  <span className="text-xs text-slate-400 dark:text-slate-500 block truncate">
                    {city.admin1 ? `${city.admin1}, ` : ''}{city.country}
                    {city.population ? ` · Pop: ${city.population.toLocaleString()}` : ''}
                  </span>
                </div>
              </button>
            ))
          )}
        </div>
      )}
    </div>
  );
}
