import { Cloud, Bus, MessageSquareWarning } from 'lucide-react';

export function FeedStatusFooter() {
  const feeds = [
    { name: 'Open-Meteo Weather', status: 'Live', icon: Cloud },
    { name: 'Transit Feed', status: 'Derived', icon: Bus },
    { name: 'Civic Reports', status: 'Derived', icon: MessageSquareWarning },
  ];

  return (
    <div className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 sm:px-6 py-3 mt-6">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center gap-3 justify-center sm:justify-start">
        <span className="text-xs font-medium text-slate-400 dark:text-slate-500">Data Sources:</span>
        {feeds.map((feed) => (
          <div
            key={feed.name}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700"
          >
            <feed.icon className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-xs text-slate-600 dark:text-slate-400">
              {feed.name}: <span className="text-emerald-600 dark:text-emerald-400 font-medium">{feed.status}</span>
            </span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse-slow" />
          </div>
        ))}
      </div>
    </div>
  );
}
