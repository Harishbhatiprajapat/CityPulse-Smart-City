import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import type { Zone } from '@/types';

interface LiveMapProps {
  zones: Zone[];
  selectedZoneId: number | null;
  onSelectZone: (id: number) => void;
  cityLabel: string;
}

function createIcon(color: string, isPulsing: boolean, isSelected: boolean): L.DivIcon {
  const size = isSelected ? 32 : 26;
  const ring = isPulsing
    ? `<div class="cp-pulse-ring" style="border-color:${color}"></div>`
    : '';
  return L.divIcon({
    className: 'cp-map-marker',
    html: `
      <div style="position:relative;width:${size}px;height:${size}px;">
        ${ring}
        <div style="width:${size}px;height:${size}px;border-radius:50%;background:${color};border:3px solid white;box-shadow:0 2px 8px rgba(0,0,0,0.3);display:flex;align-items:center;justify-content:center;">
          <div style="width:${size * 0.3}px;height:${size * 0.3}px;border-radius:50%;background:white;"></div>
        </div>
      </div>
    `,
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
  });
}

const statusColor: Record<string, string> = {
  normal: '#10b981',
  watch: '#f59e0b',
  alert: '#ef4444',
};

export function LiveMap({ zones, selectedZoneId, onSelectZone, cityLabel }: LiveMapProps) {
  const mapRef = useRef<L.Map | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const markersRef = useRef<Map<number, L.Marker>>(new Map());
  const onSelectRef = useRef(onSelectZone);
  onSelectRef.current = onSelectZone;

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const map = L.map(containerRef.current, {
      center: [zones[0]?.coords.lat ?? 37.77, zones[0]?.coords.lng ?? -122.42],
      zoom: 12,
      zoomControl: true,
      attributionControl: true,
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      maxZoom: 19,
    }).addTo(map);

    mapRef.current = map;

    return () => {
      map.remove();
      mapRef.current = null;
      markersRef.current.clear();
    };
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    markersRef.current.forEach((m) => m.remove());
    markersRef.current.clear();

    const latlngs: L.LatLngExpression[] = [];

    zones.forEach((zone) => {
      const color = statusColor[zone.status];
      const isSelected = zone.id === selectedZoneId;
      const icon = createIcon(color, zone.status === 'alert', isSelected);

      const marker = L.marker([zone.coords.lat, zone.coords.lng], { icon })
        .addTo(map)
        .bindTooltip(
          `<div style="font-weight:600;font-size:13px;">${zone.name}</div>
           <div style="font-size:11px;color:#64748b;">Score: ${zone.severityScore} · ${zone.status.toUpperCase()}</div>
           <div style="font-size:11px;color:#64748b;">Weather: ${zone.weather.value}</div>
           <div style="font-size:11px;color:#64748b;">Complaints: ${zone.complaints.value}</div>`,
          { permanent: false, direction: 'top', offset: [0, -10], className: 'cp-tooltip' }
        );

      marker.on('click', () => {
        onSelectRef.current(zone.id);
      });

      if (isSelected) {
        marker.bindPopup(
          `<div style="font-family:Inter,sans-serif;min-width:160px;">
            <div style="font-weight:700;font-size:14px;color:#0f172a;margin-bottom:4px;">${zone.name}</div>
            <div style="font-size:12px;color:#64748b;margin-bottom:6px;">${cityLabel}</div>
            <div style="display:flex;gap:8px;margin-bottom:2px;font-size:12px;"><span style="color:#64748b;">Weather:</span><span style="font-weight:600;color:#0f172a;">${zone.weather.value}</span></div>
            <div style="display:flex;gap:8px;margin-bottom:2px;font-size:12px;"><span style="color:#64748b;">Transit:</span><span style="font-weight:600;color:#0f172a;">${zone.transit.value}</span></div>
            <div style="display:flex;gap:8px;margin-bottom:4px;font-size:12px;"><span style="color:#64748b;">Complaints:</span><span style="font-weight:600;color:#0f172a;">${zone.complaints.value}</span></div>
            <div style="font-size:12px;font-weight:700;color:${color};">Severity: ${zone.severityScore}/100</div>
          </div>`
        ).openPopup();
      }

      markersRef.current.set(zone.id, marker);
      latlngs.push([zone.coords.lat, zone.coords.lng]);
    });

    if (latlngs.length > 0) {
      map.fitBounds(L.latLngBounds(latlngs).pad(0.3), { animate: true, duration: 0.8 });
    }
  }, [zones, selectedZoneId, cityLabel]);

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm overflow-hidden">
      <div className="flex items-center justify-between px-5 py-3 border-b border-slate-100 dark:border-slate-800">
        <h2 className="text-lg font-semibold tracking-tight text-slate-900 dark:text-white flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse-slow" />
          Live Zone Map
        </h2>
        <span className="text-xs text-slate-400 dark:text-slate-500">{cityLabel}</span>
      </div>
      <div className="relative">
        <div ref={containerRef} style={{ width: '100%', height: '420px' }} className="z-0" />
        <div className="cp-legend space-y-1">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
            <span className="text-xs text-slate-600 dark:text-slate-300">Normal</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
            <span className="text-xs text-slate-600 dark:text-slate-300">Watch</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
            <span className="text-xs text-slate-600 dark:text-slate-300">Alert</span>
          </div>
        </div>
      </div>
    </div>
  );
}
