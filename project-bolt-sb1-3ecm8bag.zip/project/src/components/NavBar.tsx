import { Activity, RefreshCw, Loader2, Sun, Moon, Search, LogOut, User, Clock } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import type { Page } from '@/types';

interface NavBarProps {
  lastUpdated: Date;
  onRefresh: () => void;
  isRefreshing: boolean;
  hasAlert: boolean;
  currentPage: Page;
  onNavigate: (page: Page) => void;
  onSearchFocus: () => void;
}

export function NavBar({
  lastUpdated,
  onRefresh,
  isRefreshing,
  hasAlert,
  currentPage,
  onNavigate,
  onSearchFocus,
}: NavBarProps) {
  const { user, signOut, theme, setTheme } = useAuth();

  const navLinks: { label: string; page: Page }[] = [
    { label: 'Dashboard', page: 'dashboard' },
    { label: 'History', page: 'history' },
    { label: 'About', page: 'about' },
  ];

  return (
    <nav className="sticky top-0 z-50 h-16 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 shadow-sm">
      <div className="max-w-7xl mx-auto h-full px-4 sm:px-6 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3 flex-shrink-0">
          <button
            onClick={() => onNavigate('dashboard')}
            className="flex items-center gap-2"
            aria-label="CityPulse home"
          >
            <div className="w-9 h-9 rounded-lg bg-blue-500 flex items-center justify-center shadow-md shadow-blue-500/30">
              <Activity className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold tracking-tight text-slate-900 dark:text-white hidden sm:inline">
              CityPulse
            </span>
          </button>
        </div>

        <div className="flex items-center gap-2 flex-1 justify-center max-w-xs">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-100 dark:bg-slate-800">
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                hasAlert ? 'bg-amber-500 animate-pulse-slow' : 'bg-emerald-500 animate-pulse-slow'
              }`}
            />
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
              {hasAlert ? 'Alert Active' : 'Live'}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 sm:gap-3 flex-shrink-0">
          <button
            onClick={onSearchFocus}
            className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-slate-600 dark:text-slate-400"
            aria-label="Search cities"
          >
            <Search className="w-4 h-4" />
          </button>

          <div className="hidden md:flex items-center gap-1 text-xs text-slate-500 dark:text-slate-400">
            <Clock className="w-3.5 h-3.5" />
            <span>
              {lastUpdated.toLocaleTimeString('en-US', {
                hour: 'numeric',
                minute: '2-digit',
                second: '2-digit',
              })}
            </span>
          </div>

          <button
            onClick={onRefresh}
            disabled={isRefreshing}
            className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-slate-600 dark:text-slate-400 disabled:opacity-50"
            aria-label="Refresh data"
          >
            {isRefreshing ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <RefreshCw className="w-4 h-4" />
            )}
          </button>

          <div className="hidden sm:flex items-center gap-1 ml-1">
            {navLinks.map((link) => (
              <button
                key={link.page}
                onClick={() => onNavigate(link.page)}
                className={`px-3 py-1.5 text-sm font-medium rounded-lg transition-colors ${
                  currentPage === link.page
                    ? 'bg-blue-50 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400'
                    : 'text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800'
                }`}
              >
                {link.label}
              </button>
            ))}
          </div>

          <button
            onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
            className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-slate-600 dark:text-slate-400"
            aria-label="Toggle theme"
          >
            {theme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
          </button>

          {user ? (
            <div className="flex items-center gap-2">
              <button
                onClick={() => onNavigate('account')}
                className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-slate-600 dark:text-slate-400"
                aria-label="Account"
              >
                <User className="w-4 h-4" />
              </button>
              <button
                onClick={signOut}
                className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-slate-600 dark:text-slate-400"
                aria-label="Sign out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => onNavigate('login')}
              className="px-3 py-1.5 text-sm font-medium rounded-lg bg-blue-500 text-white hover:bg-blue-600 transition-colors"
            >
              Sign In
            </button>
          )}
        </div>
      </div>

      <div className="sm:hidden border-t border-slate-100 dark:border-slate-800 px-4 py-2 flex items-center gap-1">
        {navLinks.map((link) => (
          <button
            key={link.page}
            onClick={() => onNavigate(link.page)}
            className={`px-3 py-1 text-sm font-medium rounded-lg transition-colors ${
              currentPage === link.page
                ? 'bg-blue-50 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            {link.label}
          </button>
        ))}
      </div>
    </nav>
  );
}
