import { useState, useEffect, useRef, useCallback } from 'react';
import { Zap, Loader2, AlertCircle } from 'lucide-react';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import { NavBar } from '@/components/NavBar';
import { AlertBanner } from '@/components/AlertBanner';
import { ZoneGrid } from '@/components/ZoneGrid';
import { TrendChart } from '@/components/TrendChart';
import { FeedStatusFooter } from '@/components/FeedStatusFooter';
import { LiveMap } from '@/components/LiveMap';
import { SearchBar } from '@/components/SearchBar';
import { AISummary } from '@/components/AISummary';
import { SeverityGauge } from '@/components/SeverityGauge';
import { HistoricalReplay } from '@/components/HistoricalReplay';
import { LoginPage } from '@/pages/LoginPage';
import { AccountPage } from '@/pages/AccountPage';
import { HistoryPage } from '@/pages/HistoryPage';
import { AboutPage } from '@/pages/AboutPage';
import { fetchWeatherData, buildZonesFromWeather, buildReplayData } from '@/lib/weatherApi';
import { supabase } from '@/lib/supabase';
import type { Zone, TrendPoint, Page, CityInfo, CitySearchResult } from '@/types';

const defaultCity: CityInfo = {
  name: 'San Francisco',
  country: 'United States',
  admin1: 'California',
  latitude: 37.7749,
  longitude: -122.4194,
  label: 'San Francisco, California, United States',
};

function AppContent() {
  const { theme, user } = useAuth();
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  const [currentCity, setCurrentCity] = useState<CityInfo>(defaultCity);
  const [zones, setZones] = useState<Zone[]>([]);
  const [trendData, setTrendData] = useState<TrendPoint[]>([]);
  const [replayData, setReplayData] = useState<Record<string, TrendPoint[]>>({});
  const [anomalyThreshold, setAnomalyThreshold] = useState(25);
  const [lastUpdated, setLastUpdated] = useState(new Date());
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [alertDismissed, setAlertDismissed] = useState(false);
  const [dismissedCity, setDismissedCity] = useState<string>('');
  const [expandedZoneId, setExpandedZoneId] = useState<number | null>(null);
  const [selectedZoneId, setSelectedZoneId] = useState<number | null>(1);
  const [searchFocused, setSearchFocused] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const currentCityRef = useRef<CityInfo>(defaultCity);
  currentCityRef.current = currentCity;

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  const loadData = useCallback(async (city: CityInfo) => {
    setIsLoading(true);
    setLoadError(null);
    try {
      const raw = await fetchWeatherData(city);
      const newZones = buildZonesFromWeather(raw, city);
      const newReplay = buildReplayData(raw);
      setZones(newZones);
      setTrendData(raw.trend24h.length > 0 ? raw.trend24h : newZones[0] ? [] : []);
      setReplayData(newReplay);
      setAnomalyThreshold(raw.anomalyThreshold || 25);
      setSelectedZoneId(newZones[0]?.id ?? 1);
      setExpandedZoneId(null);
      setAlertDismissed(false);
      setLastUpdated(new Date());
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Failed to load weather data');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData(defaultCity);
  }, [loadData]);

  const activeAlertZone = zones.find((z) => z.status === 'alert');
  const hasActiveAlert =
    !!activeAlertZone &&
    !alertDismissed &&
    dismissedCity !== currentCity.label;
  const selectedZone = zones.find((z) => z.id === selectedZoneId) ?? zones[0];

  async function handleRefresh() {
    setIsRefreshing(true);
    try {
      const raw = await fetchWeatherData(currentCityRef.current);
      const newZones = buildZonesFromWeather(raw, currentCityRef.current);
      const newReplay = buildReplayData(raw);
      setZones(newZones);
      setTrendData(raw.trend24h);
      setReplayData(newReplay);
      setLastUpdated(new Date());
    } catch {
    } finally {
      setIsRefreshing(false);
    }
  }

  function handleSimulateAlert() {
    setAlertDismissed(false);
    setDismissedCity('');
    setZones((prev) =>
      prev.map((z) =>
        z.id === 1
          ? { ...z, status: 'alert', severityScore: 85, complaints: { value: 38, trend: 'up' } }
          : z
      )
    );
  }

  function handleToggleZone(id: number) {
    setExpandedZoneId((prev) => (prev === id ? null : id));
    setSelectedZoneId(id);
  }

  async function handleSearch(cityResult: CitySearchResult) {
    const cityInfo: CityInfo = {
      name: cityResult.name,
      country: cityResult.country,
      admin1: cityResult.admin1,
      latitude: cityResult.latitude,
      longitude: cityResult.longitude,
      label: cityResult.label,
    };
    setCurrentCity(cityInfo);
    await loadData(cityInfo);

    if (user) {
      supabase
        .from('search_history')
        .insert({ query: cityResult.label, results_count: 4 })
        .then(() => {});
    }

    searchRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function handleNavigate(page: Page) {
    setCurrentPage(page);
  }

  const navBarProps = {
    lastUpdated,
    onRefresh: handleRefresh,
    isRefreshing,
    hasAlert: hasActiveAlert,
    currentPage,
    onNavigate: handleNavigate,
    onSearchFocus: () => {
      if (currentPage !== 'dashboard') {
        handleNavigate('dashboard');
      }
      setTimeout(() => {
        searchRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        setSearchFocused(true);
        setTimeout(() => setSearchFocused(false), 500);
      }, 100);
    },
  };

  if (currentPage === 'login') {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
        <NavBar {...navBarProps} />
        <LoginPage onNavigate={handleNavigate} />
      </div>
    );
  }

  if (currentPage === 'account') {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
        <NavBar {...navBarProps} />
        <AccountPage onNavigate={handleNavigate} />
      </div>
    );
  }

  if (currentPage === 'history') {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
        <NavBar {...navBarProps} />
        <HistoryPage onNavigate={handleNavigate} />
      </div>
    );
  }

  if (currentPage === 'about') {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950">
        <NavBar {...navBarProps} />
        <AboutPage onNavigate={handleNavigate} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col">
      <NavBar {...navBarProps} />

      {hasActiveAlert && activeAlertZone && (
        <AlertBanner
          message={`${activeAlertZone.name} in ${currentCity.name} — ${activeAlertZone.weather.value}. Severity score at ${activeAlertZone.severityScore}/100.`}
          onDismiss={() => {
            setAlertDismissed(true);
            setDismissedCity(currentCity.label);
          }}
        />
      )}

      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 py-6 space-y-6">
        <div ref={searchRef}>
          <SearchBar onSearch={handleSearch} autoFocus={searchFocused} />
        </div>

        <div className="flex items-center justify-center gap-2 flex-wrap">
          <span className="text-sm text-slate-500 dark:text-slate-400">
            {isLoading ? 'Loading live data for' : 'Showing live updates for'}
          </span>
          <span className="text-sm font-semibold text-blue-500">
            {currentCity.label}
          </span>
        </div>

        {loadError && (
          <div className="bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800/50 rounded-xl px-4 py-3 flex items-center gap-3">
            <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0" />
            <div>
              <p className="text-sm font-medium text-red-700 dark:text-red-300">Failed to load real-time data</p>
              <p className="text-xs text-red-500 dark:text-red-400">{loadError}. Tap refresh to retry.</p>
            </div>
          </div>
        )}

        {isLoading && (
          <div className="flex flex-col items-center justify-center py-20 gap-3">
            <Loader2 className="w-8 h-8 text-blue-500 animate-spin" />
            <p className="text-sm text-slate-500 dark:text-slate-400">Fetching real-time weather data...</p>
          </div>
        )}

        {!isLoading && !loadError && zones.length > 0 && (
          <>
            <LiveMap
              zones={zones}
              selectedZoneId={selectedZoneId}
              onSelectZone={handleToggleZone}
              cityLabel={currentCity.label}
            />

            <ZoneGrid zones={zones} expandedId={expandedZoneId} onToggle={handleToggleZone} />

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <SeverityGauge zone={selectedZone} />
              <AISummary zone={selectedZone} />
            </div>

            <TrendChart
              data={trendData}
              title={`24-Hour Activity Trend — ${currentCity.name}`}
              anomalyThreshold={anomalyThreshold}
            />

            <HistoricalReplay replayData={replayData} />
          </>
        )}
      </main>

      <FeedStatusFooter />

      <button
        onClick={handleSimulateAlert}
        className="fixed bottom-4 right-4 z-50 flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg bg-slate-800 dark:bg-slate-700 text-slate-100 hover:bg-slate-700 dark:hover:bg-slate-600 shadow-lg transition-all opacity-40 hover:opacity-100"
        aria-label="Simulate alert"
        title="Simulate Alert (demo)"
      >
        <Zap className="w-3.5 h-3.5" />
        Simulate Alert
      </button>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
