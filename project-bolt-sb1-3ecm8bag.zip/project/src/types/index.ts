export type ZoneStatus = 'normal' | 'watch' | 'alert';

export interface ZoneEvent {
  time: string;
  type: 'complaint' | 'weather' | 'transit' | 'civic';
  text: string;
}

export interface ZoneStat {
  value: string | number;
  trend: 'up' | 'down' | 'flat';
}

export interface Zone {
  id: number;
  name: string;
  city: string;
  status: ZoneStatus;
  coords: { lat: number; lng: number };
  polygon: { lat: number; lng: number }[];
  weather: ZoneStat;
  transit: ZoneStat;
  complaints: ZoneStat;
  severityScore: number;
  recentEvents: ZoneEvent[];
  aiSummary: string;
  correlation: string;
}

export interface TrendPoint {
  hour: string;
  complaints: number;
  transit: number;
  weather: number;
}

export type Theme = 'light' | 'dark';

export type Page = 'dashboard' | 'login' | 'account' | 'history' | 'about';

export interface CitySearchResult {
  id: number;
  name: string;
  country: string;
  admin1?: string;
  latitude: number;
  longitude: number;
  population?: number | null;
  timezone?: string | null;
  label: string;
}

export interface CityInfo {
  name: string;
  country: string;
  admin1?: string;
  latitude: number;
  longitude: number;
  label: string;
}

export interface WeatherZoneRaw {
  zoneName: string;
  latitude: number;
  longitude: number;
  current: {
    temperature: number;
    windspeed: number;
    weathercode: number;
    weatherLabel: string;
    precipitation: number;
    humidity: number;
  };
  derived: {
    transitDelay: number;
    complaintCount: number;
    severityScore: number;
    status: ZoneStatus;
    weatherSeverity: number;
  };
  hourly24: TrendPoint[];
  daily7: TrendPoint[];
  daily30: TrendPoint[];
}

export interface WeatherApiResponse {
  zones: WeatherZoneRaw[];
  citySeverity: number;
  trend24h: TrendPoint[];
  anomalyThreshold: number;
  timestamp: string;
  error?: string;
}
